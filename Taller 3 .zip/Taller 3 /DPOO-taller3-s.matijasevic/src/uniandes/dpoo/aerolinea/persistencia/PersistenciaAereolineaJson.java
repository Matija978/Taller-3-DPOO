package uniandes.dpoo.aerolinea.persistencia;

import uniandes.dpoo.aerolinea.modelo.Aerolinea;

public class PersistenciaAereolineaJson {
	public void cargarAereolinea(String archivo, Aerolinea aereolinea) {
		
	}
	public void salvarAerolinea(String archivo, Aerolinea aereolinea) {
		
	}
}

