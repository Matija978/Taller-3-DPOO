package uniandes.dpoo.aerolinea.modelo;

public class Aereopuerto {

}
